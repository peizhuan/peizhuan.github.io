*********************************************************************************************

The eight programs that start with "sim" execute simulations for four DGP's and two polynomial orders.

The DGP's come from quintic models that mimic the empirical patterns in two kink samples of the Austrian data: kink3 and kink4. For each sample, we fit either separate quintics on two sides of the threshold, or a smooth quintic across the threshold.

Hence we have four DGP's:

kink3_quintic (with kink)
kink4_quintic (with kink)
kink3_nokink_smooth_quintic
kink4_nokink_smooth_quintic

The _ll and _lq suffix denotes the polynomial orders.

*********************************************************************************************

The two files that start from "report" read the simulation data files and list the summary stats, which are then pasted into the Excel spreadsheets. 